

<?php
include 'connection.php';

$ids = isset($_GET['id']) ? $_GET['id'] : null;
$arrdata = [];

if ($ids) {
    $showquery = "SELECT * FROM jobregistration WHERE id={$ids}";
    $showdata = mysqli_query($conn, $showquery);

    if ($showdata) {
        $arrdata = mysqli_fetch_array($showdata);
    }
}

if (isset($_POST['submit'])) {
    $name = $_POST['user'];
    $degree = $_POST['degree'];
    $mobile = $_POST['number'];
    $email = $_POST['email'];
    $refer = $_POST['refer'];
    $jobprofile = $_POST['jobprofile'];

    // Use prepared statement to prevent SQL injection
    $insertQuery = "INSERT INTO jobregistration (name, degree, mobile, email, refer, jobpost) 
                    VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $insertQuery);
    mysqli_stmt_bind_param($stmt, "ssssss", $name, $degree, $mobile, $email, $refer, $jobprofile);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Data inserted successfully!'); window.location.href='display.php';</script>";
    } else {
        echo "<script>alert('Data insertion failed!');</script>";
    }

    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Developer Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="form-box">
            <h1>Apply for Web Developer Post</h1>
            <p>Please fill in all details carefully.</p>
            <form action="index.php" method="POST">
                <div class="input-group">
                    <input type="text" name="user" placeholder="Full Name *" value="<?php echo isset($arrdata['name']) ? $arrdata['name'] : ''; ?>" required>
                    <input type="text" name="degree" placeholder="Qualification *" value="<?php echo isset($arrdata['degree']) ? $arrdata['degree'] : ''; ?>" required>
                </div>
                <div class="input-group">
                    <input type="tel" name="number" placeholder="Mobile Number *" value="<?php echo isset($arrdata['mobile']) ? $arrdata['mobile'] : ''; ?>" required>
                    <input type="email" name="email" placeholder="Email ID *" value="<?php echo isset($arrdata['email']) ? $arrdata['email'] : ''; ?>" required>
                </div>
                <div class="input-group">
                    <input type="text" name="refer" placeholder="Reference (Optional)" value="<?php echo isset($arrdata['refer']) ? $arrdata['refer'] : ''; ?>">
                    <input type="text" name="jobprofile" value="Web Developer" readonly>
                </div>
                <button type="submit" name="submit" class="btn">Register</button>
            </form>
            <a href="display.php" class="view-btn">View Applications</a>
        </div>
    </div>
</body>
</html>
