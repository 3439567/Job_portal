<?php
include 'connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $deleteQuery = "DELETE FROM jobregistration WHERE id=?";
    
    $stmt = mysqli_prepare($conn, $deleteQuery);
    mysqli_stmt_bind_param($stmt, "i", $id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Record Deleted Successfully!'); window.location.href='display.php';</script>";
    } else {
        echo "<script>alert('Deletion Failed!');</script>";
    }

    mysqli_stmt_close($stmt);
} else {
    echo "<script>alert('No ID provided!');</script>";
}
?>
