<?php
include 'connection.php';

// Get the ID from the URL
if (isset($_GET['id'])) {
    $ids = $_GET['id'];

    // Fetch data from the database
    $showquery = "SELECT * FROM jobregistration WHERE id=$ids";
    $showdata = mysqli_query($conn, $showquery);  // ✅ Corrected

    if ($showdata) {
        $arrdata = mysqli_fetch_assoc($showdata);
    } else {
        die("Error fetching data: " . mysqli_error($conn));
    }
} else {
    die("ID not provided in URL!");
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $name = $_POST['user'];
    $degree = $_POST['degree'];
    $mobile = $_POST['number'];
    $email = $_POST['email'];
    $refer = $_POST['refer'];
    $jobprofile = $_POST['jobprofile'];

    // Update query
    $updateQuery = "UPDATE jobregistration SET name=?, degree=?, mobile=?, email=?, refer=?, jobpost=? WHERE id=?";
    
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "ssssssi", $name, $degree, $mobile, $email, $refer, $jobprofile, $ids);

    if (mysqli_stmt_execute($stmt)) {
        echo "<script>alert('Record Updated Successfully!');</script>";
    } else {
        echo "<script>alert('Update Failed!');</script>";
    }

    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Web Developer Application</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Update Your Application</h2>
        <form action="" method="POST">
            <input type="text" placeholder="Enter your name *" name="user" value="<?php echo $arrdata['name']; ?>" required>
            <input type="text" placeholder="Enter your qualification *" name="degree" value="<?php echo $arrdata['degree']; ?>" required>
            <input type="tel" placeholder="Mobile number *" name="number" value="<?php echo $arrdata['mobile']; ?>" required>
            <input type="email" placeholder="Email ID *" name="email" value="<?php echo $arrdata['email']; ?>" required>
            <input type="text" placeholder="Any references *" name="refer" value="<?php echo $arrdata['refer']; ?>">
            <input type="text" name="jobprofile" value="Web Developer" readonly>
            <button type="submit" name="submit">Update</button>
        </form>
    </div>
</body>
</html>
