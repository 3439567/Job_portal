<?php
$server = "localhost";  // Default XAMPP host
$user = "root";         // Default XAMPP username
$password = "";         // Default XAMPP password (empty)
$database = "crudyoutueb"; // Ensure this database exists

$conn = mysqli_connect($server, $user, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
