<?php 
include 'connection.php';

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

$selectquery = "SELECT * FROM jobregistration";
$query = mysqli_query($conn, $selectquery);

if (!$query) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Candidates</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- jQuery & Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Initialize Tooltip -->
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();
        });
    </script>

    <style>
        body {
            background: linear-gradient(135deg, #ff9a9e, #fad0c4, #fad0c4, #ffdde1);
            font-family: 'Poppins', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            margin: 0;
        }

        .main-div {
            width: 85%;
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.2);
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.3);
        }

        thead {
            background: linear-gradient(90deg, #ff416c, #ff4b2b);
            color: white;
        }

        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 2px solid #eee;
        }

        tbody tr:nth-child(odd) {
            background: #f9f9f9;
        }

        tbody tr:hover {
            background: #ffe0e9;
            transition: 0.3s ease-in-out;
        }

        /* Icon Styling */
        .fa-edit { color: green; cursor: pointer; }
        .fa-trash { color: red; cursor: pointer; transition: transform 0.3s ease, color 0.3s; }
        .fa-trash:hover { color: #ff0000; transform: scale(1.2); }
    </style>
</head>
<body>

<div class="main-div">
    <h1>🌟 List of Candidates for Web Developer Jobs 🌟</h1>

    <div class="center-div">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Degree</th>
                        <th>Mobile</th>
                        <th>Email</th>
                        <th>Reference</th>
                        <th>Post</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($res = mysqli_fetch_assoc($query)) { ?>
                        <tr>
                            <td><?php echo $res['id']; ?></td>
                            <td><?php echo $res['name']; ?></td>
                            <td><?php echo $res['degree']; ?></td>
                            <td><?php echo $res['mobile']; ?></td>
                            <td><?php echo $res['email']; ?></td>
                            <td><?php echo $res['refer']; ?></td>
                            <td><?php echo $res['jobpost']; ?></td>
                            <td>
                                <a href="updates.php?id=<?php echo $res['id']; ?>" data-toggle="tooltip" title="Edit">
                                    <i class='fa fa-edit'></i>
                                </a>  
                                &nbsp;&nbsp;
                                <a href="delete.php?id=<?php echo $res['id']; ?>" onclick="return confirm('Are you sure you want to delete?')" data-toggle="tooltip" title="Delete">
                                    <i class='fa fa-trash'></i>
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
